import { useGetStats, useGetBotStatus } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Activity, Key, Users, AlertTriangle, ShieldCheck, Wifi, WifiOff } from "lucide-react";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetStats();
  const { data: botStatus, isLoading: botLoading } = useGetBotStatus();

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold uppercase tracking-wider text-foreground">Overview</h1>
            <p className="text-xs text-muted-foreground mt-0.5 uppercase tracking-wider">System Dashboard</p>
          </div>

          {/* Bot status pill */}
          <div className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-semibold uppercase tracking-wide transition-all ${
            botLoading
              ? "bg-muted/40 border-border/50 text-muted-foreground"
              : botStatus?.online
              ? "bg-primary/10 border-primary/25 text-primary shadow-[0_0_16px_-4px_hsl(158_100%_42%/0.3)]"
              : "bg-destructive/10 border-destructive/25 text-destructive"
          }`}>
            {botLoading ? (
              <span className="animate-pulse">Checking...</span>
            ) : botStatus?.online ? (
              <>
                <Wifi size={14} />
                <span>Online</span>
                {botStatus.botUsername && (
                  <span className="text-primary/60 font-normal">@{botStatus.botUsername}</span>
                )}
                <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              </>
            ) : (
              <>
                <WifiOff size={14} />
                <span>Offline</span>
              </>
            )}
          </div>
        </div>

        {/* Stats grid */}
        {statsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-28 rounded-2xl bg-card border border-border/50 animate-pulse" />
            ))}
          </div>
        ) : stats ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <StatCard title="Total Keys"    value={stats.totalKeys}    icon={Key}           color="primary"      />
            <StatCard title="Active Keys"   value={stats.activeKeys}   icon={Activity}      color="primary"      />
            <StatCard title="Locked Keys"   value={stats.lockedKeys}   icon={ShieldCheck}   color="chart-4"      />
            <StatCard title="Expired Keys"  value={stats.expiredKeys}  icon={AlertTriangle} color="destructive"  />
            <StatCard title="Sellers"       value={stats.sellersCount} icon={Users}         color="chart-2"      />
          </div>
        ) : null}
      </div>
    </Layout>
  );
}

function StatCard({
  title, value, icon: Icon, color,
}: {
  title: string; value: number; icon: any; color: string;
}) {
  const colorMap: Record<string, { bg: string; border: string; text: string; glow: string }> = {
    primary:     { bg: "bg-primary/8",     border: "border-primary/20",     text: "text-primary",     glow: "shadow-[0_0_20px_-6px_hsl(158_100%_42%/0.3)]" },
    "chart-2":   { bg: "bg-teal-500/8",    border: "border-teal-500/20",    text: "text-teal-400",    glow: "shadow-[0_0_20px_-6px_rgba(45,212,191,0.25)]" },
    "chart-4":   { bg: "bg-blue-500/8",    border: "border-blue-500/20",    text: "text-blue-400",    glow: "shadow-[0_0_20px_-6px_rgba(96,165,250,0.25)]" },
    destructive: { bg: "bg-red-500/8",     border: "border-red-500/20",     text: "text-red-400",     glow: "shadow-[0_0_20px_-6px_rgba(248,113,113,0.2)]" },
  };
  const c = colorMap[color] ?? colorMap.primary;

  return (
    <div className={`relative overflow-hidden rounded-2xl border ${c.border} ${c.bg} ${c.glow} p-5 flex items-center gap-4 transition-all hover:scale-[1.01]`}>
      <div className={`w-12 h-12 rounded-xl ${c.bg} border ${c.border} flex items-center justify-center shrink-0`}>
        <Icon className={`w-6 h-6 ${c.text}`} />
      </div>
      <div>
        <p className="text-xs uppercase text-muted-foreground tracking-wider font-semibold">{title}</p>
        <p className={`text-3xl font-bold mt-0.5 ${c.text}`}>{value}</p>
      </div>
    </div>
  );
}
