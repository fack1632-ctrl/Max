import { useListPrices, useUpdatePrice, getListPricesQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { DollarSign, Edit2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function Prices() {
  const { data: prices, isLoading } = useListPrices();

  const [editOpen, setEditOpen] = useState<{ isOpen: boolean; type: string; duration: number; price: number }>({
    isOpen: false,
    type: "",
    duration: 0,
    price: 0,
  });
  const [newPrice, setNewPrice] = useState("");

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updatePrice = useUpdatePrice();

  const handleEdit = (price: { type: string; duration_days: number; price: number }) => {
    setEditOpen({ isOpen: true, type: price.type, duration: price.duration_days, price: price.price });
    setNewPrice(price.price.toString());
  };

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editOpen.type) return;
    updatePrice.mutate(
      { data: { type: editOpen.type, duration_days: editOpen.duration, price: parseFloat(newPrice) } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListPricesQueryKey() });
          setEditOpen({ ...editOpen, isOpen: false });
          toast({ title: "Pricing table updated" });
        },
        onError: () => toast({ title: "Update failed", variant: "destructive" }),
      }
    );
  };

  return (
    <Layout>
      <div className="p-8 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <DollarSign className="text-primary w-8 h-8" />
            <h1 className="text-2xl font-bold uppercase tracking-wider">Pricing Configuration</h1>
          </div>
        </div>

        <Dialog open={editOpen.isOpen} onOpenChange={(open) => setEditOpen({ ...editOpen, isOpen: open })}>
          <DialogContent className="border-border bg-card">
            <DialogHeader>
              <DialogTitle className="uppercase tracking-wider font-mono">
                Update Price: {editOpen.type.toUpperCase()} / {editOpen.duration} Days
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleUpdate} className="space-y-4 pt-4">
              <div className="space-y-2">
                <label className="text-xs uppercase text-muted-foreground font-semibold">New Price ($)</label>
                <Input
                  type="number"
                  step="0.01"
                  value={newPrice}
                  onChange={(e) => setNewPrice(e.target.value)}
                  className="font-mono"
                  required
                />
              </div>
              <Button type="submit" className="w-full uppercase font-bold" disabled={updatePrice.isPending}>
                {updatePrice.isPending ? "Committing..." : "Commit Change"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <div className="border border-border rounded-lg bg-card overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="font-mono uppercase text-xs">Tier</TableHead>
                <TableHead className="font-mono uppercase text-xs">Duration</TableHead>
                <TableHead className="font-mono uppercase text-xs text-right">Price</TableHead>
                <TableHead className="font-mono uppercase text-xs text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="font-mono text-sm">
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                    Retrieving data...
                  </TableCell>
                </TableRow>
              ) : prices?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                    No records found
                  </TableCell>
                </TableRow>
              ) : (
                prices?.map((price) => (
                  <TableRow key={`${price.type}-${price.duration_days}`} className="border-border hover:bg-muted/30">
                    <TableCell className={`font-bold uppercase ${price.type === "pro" ? "text-chart-2" : "text-primary"}`}>
                      {price.type}
                    </TableCell>
                    <TableCell className="text-muted-foreground">{price.duration_days} Days</TableCell>
                    <TableCell className="text-right font-bold tracking-wider text-primary">
                      ${price.price.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="outline"
                        size="icon"
                        title="Edit Price"
                        onClick={() => handleEdit(price)}
                        className="border-border hover:text-primary hover:border-primary"
                      >
                        <Edit2 size={14} />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </Layout>
  );
}
