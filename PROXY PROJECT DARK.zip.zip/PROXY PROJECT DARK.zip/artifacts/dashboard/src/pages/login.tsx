import { useToast } from "@/hooks/use-toast";
import { useLogin } from "@workspace/api-client-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { setToken } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Terminal, Lock } from "lucide-react";

export default function Login() {
  const [password, setPassword] = useState("");
  const login = useLogin();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login.mutate(
      { data: { password } },
      {
        onSuccess: (data) => {
          setToken(data.token);
          setLocation("/dashboard");
        },
        onError: () => {
          toast({
            title: "Access Denied",
            description: "Invalid password",
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      {/* Background glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[500px] h-[500px] rounded-full bg-primary/5 blur-3xl" />
      </div>

      <div className="relative w-full max-w-sm space-y-6">
        {/* Logo */}
        <div className="flex flex-col items-center gap-3">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center shadow-[0_0_32px_-8px_hsl(158_100%_42%/0.4)]">
            <Terminal size={32} className="text-primary" />
          </div>
          <div className="text-center">
            <h1 className="text-xl font-bold uppercase tracking-widest text-primary">FF_PROXY</h1>
            <p className="text-xs text-muted-foreground mt-1 uppercase tracking-widest">Control Panel</p>
          </div>
        </div>

        {/* Card */}
        <form
          onSubmit={handleLogin}
          className="space-y-4 bg-card border border-border/70 p-6 rounded-2xl shadow-[0_8px_32px_-8px_rgba(0,0,0,0.6)]"
        >
          <div className="space-y-1.5">
            <label className="text-xs uppercase text-muted-foreground tracking-wider font-semibold flex items-center gap-1.5">
              <Lock size={11} /> Authentication Required
            </label>
            <Input
              type="password"
              placeholder="Enter password"
              className="bg-background/80 border-border/60 font-mono text-foreground placeholder:text-muted-foreground/50 focus-visible:ring-primary/40 rounded-xl h-11"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={login.isPending}
            />
          </div>
          <Button
            type="submit"
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-bold uppercase tracking-wider rounded-xl h-11 shadow-[0_0_16px_-4px_hsl(158_100%_42%/0.5)] transition-all hover:shadow-[0_0_24px_-4px_hsl(158_100%_42%/0.6)]"
            disabled={login.isPending}
          >
            {login.isPending ? "Authenticating..." : "Sign In"}
          </Button>
        </form>
      </div>
    </div>
  );
}
