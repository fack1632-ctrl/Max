import { useListKeys, useDeleteKey, useResetKeyIp, getListKeysQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, RefreshCw, KeyIcon } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { getToken } from "@/lib/auth";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const RESET_MAX = 4;

export default function Keys() {
  const { data: keys, isLoading } = useListKeys();
  const [createOpen, setCreateOpen] = useState(false);
  const [type, setType] = useState("basic");
  const [duration, setDuration] = useState("30");
  const [quantity, setQuantity] = useState("1");
  const [creating, setCreating] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deleteKey = useDeleteKey();
  const resetIp = useResetKeyIp();

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const qty = Math.max(1, Math.min(50, parseInt(quantity) || 1));
    const days = parseInt(duration, 10);
    if (!days || days < 1) return;

    setCreating(true);
    try {
      const res = await fetch(`${BASE}/api/keys/batch`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${getToken()}`,
        },
        body: JSON.stringify({ type, duration_days: days, count: qty }),
      });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      queryClient.invalidateQueries({ queryKey: getListKeysQueryKey() });
      setCreateOpen(false);
      toast({ title: `✅ ${data.keys?.length ?? qty} key(s) generated successfully` });
    } catch {
      toast({ title: "Failed to generate keys", variant: "destructive" });
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = (id: number) => {
    deleteKey.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListKeysQueryKey() });
          toast({ title: "Key deleted" });
        },
      }
    );
  };

  const handleResetIp = (id: number) => {
    resetIp.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListKeysQueryKey() });
          toast({ title: "IP cleared — key ready for new device" });
        },
        onError: (err: any) => {
          const msg: string = err?.response?.data?.error ?? err?.message ?? "Reset failed";
          toast({ title: "Cannot reset", description: msg, variant: "destructive" });
          queryClient.invalidateQueries({ queryKey: getListKeysQueryKey() });
        },
      }
    );
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <KeyIcon className="text-primary w-4 h-4" />
            </div>
            <div>
              <h1 className="text-xl font-bold uppercase tracking-wider">Access Keys</h1>
              <p className="text-xs text-muted-foreground uppercase tracking-wider">
                {keys?.length ?? 0} total keys
              </p>
            </div>
          </div>

          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button className="font-bold uppercase tracking-wider gap-2 rounded-xl">
                <Plus size={15} /> Generate Keys
              </Button>
            </DialogTrigger>
            <DialogContent className="border-border bg-card rounded-2xl">
              <DialogHeader>
                <DialogTitle className="uppercase tracking-wider font-mono">Generate Keys</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 pt-2">
                <div className="space-y-2">
                  <label className="text-xs uppercase text-muted-foreground font-semibold">Tier</label>
                  <Select value={type} onValueChange={setType}>
                    <SelectTrigger className="font-mono rounded-xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">🔵 Basic</SelectItem>
                      <SelectItem value="pro">⭐ Pro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase text-muted-foreground font-semibold">Duration (Days)</label>
                  <Select value={duration} onValueChange={setDuration}>
                    <SelectTrigger className="font-mono rounded-xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 Day</SelectItem>
                      <SelectItem value="7">7 Days — 1 Week</SelectItem>
                      <SelectItem value="30">30 Days — 1 Month</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    className="font-mono rounded-xl"
                    min="1"
                    placeholder="Custom days..."
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase text-muted-foreground font-semibold">
                    Quantity <span className="text-muted-foreground/60">(max 50)</span>
                  </label>
                  <div className="flex gap-2">
                    {[1, 3, 5, 10].map((q) => (
                      <button
                        key={q}
                        type="button"
                        onClick={() => setQuantity(String(q))}
                        className={`flex-1 py-2 rounded-xl border text-sm font-bold transition-all ${
                          quantity === String(q)
                            ? "bg-primary/15 border-primary/40 text-primary"
                            : "border-border/60 text-muted-foreground hover:border-primary/30 hover:text-foreground"
                        }`}
                      >
                        ×{q}
                      </button>
                    ))}
                  </div>
                  <Input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="font-mono rounded-xl"
                    min="1"
                    max="50"
                    placeholder="Or enter custom quantity..."
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full uppercase font-bold rounded-xl"
                  disabled={creating}
                >
                  {creating ? "Generating..." : `Generate ${parseInt(quantity) > 1 ? parseInt(quantity) + " Keys" : "Key"}`}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="border border-border/60 rounded-2xl bg-card overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow className="border-border/50 hover:bg-transparent">
                <TableHead className="font-mono uppercase text-xs text-muted-foreground">ID</TableHead>
                <TableHead className="font-mono uppercase text-xs text-muted-foreground">Key</TableHead>
                <TableHead className="font-mono uppercase text-xs text-muted-foreground">Type</TableHead>
                <TableHead className="font-mono uppercase text-xs text-muted-foreground">Status</TableHead>
                <TableHead className="font-mono uppercase text-xs text-muted-foreground">Expiry</TableHead>
                <TableHead className="font-mono uppercase text-xs text-muted-foreground">Locked IP</TableHead>
                <TableHead className="font-mono uppercase text-xs text-muted-foreground text-center">Resets</TableHead>
                <TableHead className="font-mono uppercase text-xs text-muted-foreground text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="font-mono text-sm">
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                    Retrieving data...
                  </TableCell>
                </TableRow>
              ) : keys?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                    No keys found
                  </TableCell>
                </TableRow>
              ) : (
                keys?.map((key) => {
                  const resetCount = (key as any).reset_count ?? 0;
                  const resetExhausted = resetCount >= RESET_MAX;
                  const isExpired = new Date(key.expires_at) < new Date();

                  return (
                    <TableRow key={key.id} className="border-border/40 hover:bg-muted/20 transition-colors">
                      <TableCell className="text-muted-foreground text-xs">#{key.id}</TableCell>
                      <TableCell className="font-bold tracking-wider text-xs">{key.key}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={`uppercase text-xs rounded-lg ${
                            key.type === "pro"
                              ? "border-teal-500/40 text-teal-400 bg-teal-500/8"
                              : "border-primary/40 text-primary bg-primary/8"
                          }`}
                        >
                          {key.type === "pro" ? "⭐ Pro" : "🔵 Basic"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={`uppercase text-xs rounded-lg ${
                            isExpired
                              ? "border-red-500/40 text-red-400 bg-red-500/8"
                              : key.is_active
                              ? "border-primary/40 text-primary bg-primary/8"
                              : "border-border text-muted-foreground"
                          }`}
                        >
                          {isExpired ? "Expired" : key.is_active ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-xs">
                        {new Date(key.expires_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-xs">
                        {key.locked_ip ? (
                          <span className="text-blue-400 font-mono">{key.locked_ip}</span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          {[...Array(RESET_MAX)].map((_, i) => (
                            <div
                              key={i}
                              className={`w-2 h-2 rounded-full transition-colors ${
                                i < resetCount
                                  ? resetExhausted ? "bg-red-500" : "bg-primary"
                                  : "bg-muted-foreground/25"
                              }`}
                            />
                          ))}
                          <span className={`text-xs ml-1 font-bold ${resetExhausted ? "text-red-400" : "text-muted-foreground"}`}>
                            {resetCount}/{RESET_MAX}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="outline"
                            size="icon"
                            title={resetExhausted ? "Max resets reached (4/4)" : !key.locked_ip ? "No IP locked" : "Reset locked IP"}
                            onClick={() => handleResetIp(key.id)}
                            disabled={resetIp.isPending || resetExhausted}
                            className={`w-8 h-8 rounded-lg border-border/60 transition-colors ${
                              resetExhausted ? "opacity-30 cursor-not-allowed" : "hover:text-blue-400 hover:border-blue-500/50"
                            }`}
                          >
                            <RefreshCw size={13} />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            title="Delete key"
                            onClick={() => handleDelete(key.id)}
                            disabled={deleteKey.isPending}
                            className="w-8 h-8 rounded-lg border-border/60 hover:text-red-400 hover:border-red-500/50 transition-colors"
                          >
                            <Trash2 size={13} />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </Layout>
  );
}
