import { useListSellers, useAddSeller, useRemoveSeller, useAddBalance, getListSellersQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Users, Plus, Trash2, Wallet } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function Sellers() {
  const { data: sellers, isLoading } = useListSellers();
  const [addOpen, setAddOpen] = useState(false);
  const [userId, setUserId] = useState("");
  const [username, setUsername] = useState("");

  const [balanceOpen, setBalanceOpen] = useState<{ isOpen: boolean; userId: number | null }>({ isOpen: false, userId: null });
  const [amount, setAmount] = useState("");

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const addSeller = useAddSeller();
  const removeSeller = useRemoveSeller();
  const addBalance = useAddBalance();

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    addSeller.mutate(
      { data: { user_id: parseInt(userId, 10), username: username || null } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSellersQueryKey() });
          setAddOpen(false);
          setUserId("");
          setUsername("");
          toast({ title: "Seller authorized" });
        },
        onError: () => toast({ title: "Failed to authorize seller", variant: "destructive" }),
      }
    );
  };

  const handleRemove = (id: number) => {
    removeSeller.mutate(
      { userId: id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSellersQueryKey() });
          toast({ title: "Seller access revoked" });
        },
      }
    );
  };

  const handleAddBalance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!balanceOpen.userId) return;
    addBalance.mutate(
      { userId: balanceOpen.userId, data: { amount: parseFloat(amount) } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSellersQueryKey() });
          setBalanceOpen({ isOpen: false, userId: null });
          setAmount("");
          toast({ title: "Funds allocated" });
        },
        onError: () => toast({ title: "Transaction failed", variant: "destructive" }),
      }
    );
  };

  return (
    <Layout>
      <div className="p-8 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Users className="text-primary w-8 h-8" />
            <h1 className="text-2xl font-bold uppercase tracking-wider">Distributors</h1>
          </div>

          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button className="font-bold uppercase tracking-wider gap-2">
                <Plus size={16} /> Authorize Seller
              </Button>
            </DialogTrigger>
            <DialogContent className="border-border bg-card">
              <DialogHeader>
                <DialogTitle className="uppercase tracking-wider font-mono">Authorize New Seller</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAdd} className="space-y-4 pt-4">
                <div className="space-y-2">
                  <label className="text-xs uppercase text-muted-foreground font-semibold">Telegram User ID</label>
                  <Input
                    type="number"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value)}
                    className="font-mono"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase text-muted-foreground font-semibold">Username (Optional)</label>
                  <Input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="font-mono"
                  />
                </div>
                <Button type="submit" className="w-full uppercase font-bold" disabled={addSeller.isPending}>
                  {addSeller.isPending ? "Processing..." : "Authorize"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Dialog
          open={balanceOpen.isOpen}
          onOpenChange={(open) => setBalanceOpen({ isOpen: open, userId: open ? balanceOpen.userId : null })}
        >
          <DialogContent className="border-border bg-card">
            <DialogHeader>
              <DialogTitle className="uppercase tracking-wider font-mono">Allocate Funds</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddBalance} className="space-y-4 pt-4">
              <div className="space-y-2">
                <label className="text-xs uppercase text-muted-foreground font-semibold">Amount</label>
                <Input
                  type="number"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="font-mono"
                  required
                />
              </div>
              <Button type="submit" className="w-full uppercase font-bold" disabled={addBalance.isPending}>
                {addBalance.isPending ? "Transferring..." : "Confirm Transfer"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <div className="border border-border rounded-lg bg-card overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="font-mono uppercase text-xs">User ID</TableHead>
                <TableHead className="font-mono uppercase text-xs">Username</TableHead>
                <TableHead className="font-mono uppercase text-xs text-right">Balance</TableHead>
                <TableHead className="font-mono uppercase text-xs">Added On</TableHead>
                <TableHead className="font-mono uppercase text-xs text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="font-mono text-sm">
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    Retrieving data...
                  </TableCell>
                </TableRow>
              ) : sellers?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    No records found
                  </TableCell>
                </TableRow>
              ) : (
                sellers?.map((seller) => (
                  <TableRow key={seller.user_id} className="border-border hover:bg-muted/30">
                    <TableCell className="font-bold text-primary">{seller.user_id}</TableCell>
                    <TableCell>
                      {seller.username ? (
                        <span className="text-muted-foreground">@{seller.username}</span>
                      ) : (
                        <span className="text-muted-foreground opacity-50">N/A</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-bold tracking-wider text-chart-2">
                      ${seller.balance.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(seller.added_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button
                        variant="outline"
                        size="icon"
                        title="Add Balance"
                        onClick={() => setBalanceOpen({ isOpen: true, userId: seller.user_id })}
                        className="border-border hover:text-chart-2 hover:border-chart-2"
                      >
                        <Wallet size={14} />
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        title="Revoke Access"
                        onClick={() => handleRemove(seller.user_id)}
                        disabled={removeSeller.isPending}
                        className="border-border hover:text-destructive hover:border-destructive"
                      >
                        <Trash2 size={14} />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </Layout>
  );
}
