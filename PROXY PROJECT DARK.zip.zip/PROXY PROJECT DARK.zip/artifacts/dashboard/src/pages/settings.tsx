import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Settings2, RefreshCw, Upload, CheckCircle2, Trash2, FileKey, Globe, Star, Server } from "lucide-react";
import { useState, useEffect, useMemo, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { getToken } from "@/lib/auth";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const api = (path: string, opts?: RequestInit) =>
  fetch(`${BASE}${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json", ...opts?.headers },
  });

const CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
function generatePreview(fmt: string): string {
  return fmt.split("").map((ch) => (ch === "X" ? CHARS[Math.floor(Math.random() * CHARS.length)] : ch)).join("");
}

const STAR_LABELS: Record<string, string> = {
  basic_1: "🔵 Basic — 1 Day",   basic_7: "🔵 Basic — 1 Week",  basic_30: "🔵 Basic — 1 Month",
  pro_1:   "⭐ Pro — 1 Day",     pro_7:   "⭐ Pro — 1 Week",    pro_30:   "⭐ Pro — 1 Month",
};

export default function Settings() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  // ── Key format ──
  const { data: fmtData, isLoading: fmtLoading } = useQuery({
    queryKey: ["key-format"],
    queryFn: () => api("/api/settings/key-format").then((r) => r.json()),
  });
  const [format, setFormat] = useState("");
  const [previewKey, setPreviewKey] = useState("");
  const randomCount = useMemo(() => (format.match(/X/g) ?? []).length, [format]);
  const refreshPreview = () => setPreviewKey(generatePreview(format));

  useEffect(() => {
    if (fmtData?.format) { setFormat(fmtData.format); setPreviewKey(generatePreview(fmtData.format)); }
  }, [fmtData]);

  const formatMutation = useMutation({
    mutationFn: (fmt: string) =>
      api("/api/settings/key-format", { method: "PUT", body: JSON.stringify({ format: fmt }) }).then((r) => r.json()),
    onSuccess: (res) => {
      queryClient.setQueryData(["key-format"], res);
      setPreviewKey(generatePreview(res.format));
      toast({ title: "Key format saved" });
    },
    onError: () => toast({ title: "Failed to save", variant: "destructive" }),
  });

  // ── Certificate ──
  const { data: certData, isLoading: certLoading } = useQuery({
    queryKey: ["cert-status"],
    queryFn: () => api("/api/settings/cert").then((r) => r.json()),
  });

  const uploadMutation = useMutation({
    mutationFn: (content: string) =>
      api("/api/settings/cert", { method: "POST", body: JSON.stringify({ content }) }).then((r) => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["cert-status"] }); toast({ title: "Certificate uploaded" }); },
    onError: () => toast({ title: "Failed to upload certificate", variant: "destructive" }),
  });

  const deleteCertMutation = useMutation({
    mutationFn: () => api("/api/settings/cert", { method: "DELETE" }).then((r) => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["cert-status"] }); toast({ title: "Certificate removed" }); },
  });

  const handleFile = (file: File) => {
    if (!file) return;
    if (!file.name.endsWith(".pem") && !file.name.endsWith(".crt") && !file.name.endsWith(".cert")) {
      toast({ title: "Please select a .pem / .crt file", variant: "destructive" }); return;
    }
    const reader = new FileReader();
    reader.onload = (e) => uploadMutation.mutate(e.target?.result as string);
    reader.readAsText(file);
  };

  // ── Proxy Settings ──
  const { data: proxyData, isLoading: proxyLoading } = useQuery({
    queryKey: ["proxy-settings"],
    queryFn: () => api("/api/settings/proxy").then((r) => r.json()),
  });

  const [proxyIp, setProxyIp]         = useState("");
  const [portAimDrag, setPortAimDrag] = useState("");
  const [portAimBody, setPortAimBody] = useState("");
  const [portAimNeck, setPortAimNeck] = useState("");
  const [portSpeed, setPortSpeed]     = useState("");
  const [port3D, setPort3D]           = useState("");
  const [portSpeedPro, setPortSpeedPro] = useState("");

  useEffect(() => {
    if (proxyData) {
      setProxyIp(proxyData.ip ?? "");
      setPortAimDrag(String(proxyData.ports?.aim_drag ?? ""));
      setPortAimBody(String(proxyData.ports?.aim_body ?? ""));
      setPortAimNeck(String(proxyData.ports?.aim_neck ?? ""));
      setPortSpeed(String(proxyData.ports?.speed ?? ""));
      setPort3D(String(proxyData.ports?.mode_3d ?? ""));
      setPortSpeedPro(String(proxyData.ports?.speed_pro ?? ""));
    }
  }, [proxyData]);

  const proxyMutation = useMutation({
    mutationFn: () =>
      api("/api/settings/proxy", {
        method: "PUT",
        body: JSON.stringify({
          ip: proxyIp,
          ports: {
            aim_drag:  parseInt(portAimDrag),
            aim_body:  parseInt(portAimBody),
            aim_neck:  parseInt(portAimNeck),
            speed:     parseInt(portSpeed),
            mode_3d:   parseInt(port3D),
            speed_pro: parseInt(portSpeedPro),
          },
        }),
      }).then((r) => r.json()),
    onSuccess: (res) => {
      queryClient.setQueryData(["proxy-settings"], res);
      toast({ title: "Proxy settings saved" });
    },
    onError: () => toast({ title: "Failed to save proxy settings", variant: "destructive" }),
  });

  // ── Star Prices ──
  const { data: starData, isLoading: starLoading } = useQuery({
    queryKey: ["star-prices"],
    queryFn: () => api("/api/settings/star-prices").then((r) => r.json()),
  });

  const [starPrices, setStarPrices] = useState<Record<string, string>>({});

  useEffect(() => {
    if (starData) {
      const map: Record<string, string> = {};
      for (const p of starData) map[`${p.type}_${p.duration_days}`] = String(p.stars);
      setStarPrices(map);
    }
  }, [starData]);

  const starMutation = useMutation({
    mutationFn: (payload: { type: string; duration_days: number; stars: number }) =>
      api("/api/settings/star-prices", { method: "PUT", body: JSON.stringify(payload) }).then((r) => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["star-prices"] }); toast({ title: "Star price updated" }); },
    onError: () => toast({ title: "Failed to update", variant: "destructive" }),
  });

  const saveStarPrice = (key: string) => {
    const [type, days] = key.split("_");
    const stars = parseInt(starPrices[key]);
    if (!stars || stars < 1) return;
    starMutation.mutate({ type, duration_days: parseInt(days), stars });
  };

  return (
    <Layout>
      <div className="p-8 space-y-8 max-w-2xl">
        <div className="flex items-center gap-3">
          <Settings2 className="text-primary w-8 h-8" />
          <h1 className="text-2xl font-bold uppercase tracking-wider">Settings</h1>
        </div>

        {/* ── Proxy Settings ── */}
        <section className="border border-border rounded-xl bg-card p-6 space-y-5">
          <div className="flex items-center gap-3">
            <Server className="text-primary w-5 h-5" />
            <div>
              <p className="font-bold uppercase tracking-wider text-sm">Proxy Server</p>
              <p className="text-xs text-muted-foreground mt-0.5">IP address and ports sent to users</p>
            </div>
          </div>

          {proxyLoading ? (
            <div className="h-40 rounded-lg bg-muted/30 animate-pulse" />
          ) : (
            <form
              onSubmit={(e) => { e.preventDefault(); proxyMutation.mutate(); }}
              className="space-y-4"
            >
              <div className="space-y-1.5">
                <label className="text-xs uppercase text-muted-foreground font-semibold flex items-center gap-1.5">
                  <Globe size={12} /> Server IP
                </label>
                <Input value={proxyIp} onChange={(e) => setProxyIp(e.target.value)} placeholder="e.g. 178.62.48.99" className="font-mono" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: "🎯 Aim Drag Port",           value: portAimDrag, set: setPortAimDrag },
                  { label: "💥 Aim Body Port",           value: portAimBody, set: setPortAimBody },
                  { label: "🔫 Aim Neck Port",           value: portAimNeck, set: setPortAimNeck },
                  { label: "⚡ Speed Port [FF Max]",     value: portSpeed,   set: setPortSpeed   },
                  { label: "🎮 3D Mode Port [FF Max]",   value: port3D,      set: setPort3D      },
                  { label: "☣️ Speed ×1.5 Port [Pro]",  value: portSpeedPro,set: setPortSpeedPro },
                ].map(({ label, value, set }) => (
                  <div key={label} className="space-y-1.5">
                    <label className="text-xs text-muted-foreground font-semibold">{label}</label>
                    <Input value={value} onChange={(e) => set(e.target.value)} placeholder="8080" className="font-mono" type="number" min="1" max="65535" />
                  </div>
                ))}
              </div>

              <Button type="submit" className="w-full uppercase font-bold tracking-wider" disabled={proxyMutation.isPending}>
                {proxyMutation.isPending ? "Saving..." : "Save Proxy Settings"}
              </Button>
            </form>
          )}
        </section>

        {/* ── Stars Pricing ── */}
        <section className="border border-border rounded-xl bg-card p-6 space-y-5">
          <div className="flex items-center gap-3">
            <Star className="text-yellow-400 w-5 h-5" />
            <div>
              <p className="font-bold uppercase tracking-wider text-sm">Telegram Stars Prices</p>
              <p className="text-xs text-muted-foreground mt-0.5">Stars required for each key type via in-bot purchase</p>
            </div>
          </div>

          {starLoading ? (
            <div className="h-40 rounded-lg bg-muted/30 animate-pulse" />
          ) : (
            <div className="grid grid-cols-1 gap-3">
              {Object.entries(STAR_LABELS).map(([key, label]) => (
                <div key={key} className="flex items-center gap-3">
                  <span className="text-sm font-semibold w-44 shrink-0">{label}</span>
                  <Input
                    type="number"
                    min="1"
                    value={starPrices[key] ?? ""}
                    onChange={(e) => setStarPrices((prev) => ({ ...prev, [key]: e.target.value }))}
                    className="font-mono w-28"
                    placeholder="stars"
                  />
                  <span className="text-xs text-muted-foreground">⭐</span>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => saveStarPrice(key)}
                    disabled={starMutation.isPending}
                    className="text-xs uppercase tracking-wider"
                  >
                    Save
                  </Button>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* ── Certificate ── */}
        <section className="border border-border rounded-xl bg-card p-6 space-y-5">
          <div className="flex items-center gap-3">
            <FileKey className="text-primary w-5 h-5" />
            <div>
              <p className="font-bold uppercase tracking-wider text-sm">Mitmproxy Certificate</p>
              <p className="text-xs text-muted-foreground mt-0.5">The .pem file users download from the bot</p>
            </div>
            {!certLoading && (
              <span className={`ml-auto text-xs font-bold px-2 py-1 rounded-full border ${certData?.hasCert ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30" : "bg-orange-500/10 text-orange-400 border-orange-500/30"}`}>
                {certData?.hasCert ? "✓ Uploaded" : "Not set"}
              </span>
            )}
          </div>

          {certData?.hasCert && (
            <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/25 rounded-lg px-4 py-3">
              <CheckCircle2 className="text-emerald-400 w-5 h-5 shrink-0" />
              <span className="text-sm text-emerald-400 flex-1 font-medium">mitmproxy-ca-cert.pem is active</span>
              <Button variant="outline" size="sm" onClick={() => deleteCertMutation.mutate()} disabled={deleteCertMutation.isPending} className="text-red-400 border-red-500/30 hover:bg-red-500/10 text-xs">
                <Trash2 size={13} className="mr-1" /> Remove
              </Button>
            </div>
          )}

          <div
            onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-lg px-6 py-8 text-center cursor-pointer transition-all ${dragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-muted/30"}`}
          >
            <Upload className="mx-auto mb-3 text-muted-foreground w-7 h-7" />
            <p className="text-sm font-semibold">{certData?.hasCert ? "Replace certificate" : "Upload certificate"}</p>
            <p className="text-xs text-muted-foreground mt-1">Drag & drop or click — <span className="font-mono">.pem</span> / <span className="font-mono">.crt</span></p>
            {uploadMutation.isPending && <p className="text-xs text-primary mt-2 font-semibold">Uploading…</p>}
          </div>
          <input ref={fileInputRef} type="file" accept=".pem,.crt,.cert" className="hidden"
            onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); e.target.value = ""; }} />
        </section>

        {/* ── Key Format ── */}
        <section className="border border-border rounded-xl bg-card p-6 space-y-6">
          <div>
            <p className="font-bold uppercase tracking-wider text-sm mb-1">Key Format</p>
            <p className="text-xs text-muted-foreground">
              Use <span className="text-primary font-bold font-mono bg-primary/10 px-1 rounded">X</span> as wildcard (A–Z, 0–9). Everything else is kept as-is.
            </p>
            <div className="flex flex-wrap gap-2 mt-3">
              {["XXXXXXXXXXXXXXXX", "FF-XXXX-XXXX-XXXX", "PRO-XXXXXXXXXX", "FFBOT-XXXX"].map((ex) => (
                <button key={ex} onClick={() => { setFormat(ex); setPreviewKey(generatePreview(ex)); }}
                  className="text-xs font-mono bg-muted hover:bg-accent border border-border px-2 py-1 rounded transition-colors">
                  {ex}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); if (format.trim()) formatMutation.mutate(format.trim()); }} className="space-y-5">
            <div className="space-y-2">
              <label className="text-xs uppercase text-muted-foreground font-semibold">Format Template</label>
              <Input value={format} onChange={(e) => { const v = e.target.value.toUpperCase(); setFormat(v); setPreviewKey(generatePreview(v)); }}
                placeholder="XXXXXXXXXXXXXXXX" className="font-mono text-lg tracking-widest h-12" disabled={fmtLoading} />
              <p className="text-xs text-muted-foreground">{randomCount} random char{randomCount !== 1 ? "s" : ""} · {format.length} total</p>
            </div>

            {format && (
              <div className="space-y-2">
                <label className="text-xs uppercase text-muted-foreground font-semibold">Live Preview</label>
                <div className="flex items-center gap-3 bg-muted/40 border border-border rounded-md px-4 py-3">
                  <span className="font-mono text-xl font-bold text-primary tracking-widest flex-1">{previewKey}</span>
                  <button type="button" onClick={refreshPreview} className="text-muted-foreground hover:text-foreground transition-colors">
                    <RefreshCw size={16} />
                  </button>
                </div>
              </div>
            )}

            <Button type="submit" className="w-full uppercase font-bold tracking-wider" disabled={formatMutation.isPending || fmtLoading || !format.trim()}>
              {formatMutation.isPending ? "Saving..." : "Save Format"}
            </Button>
          </form>
        </section>
      </div>
    </Layout>
  );
}
