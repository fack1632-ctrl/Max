import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect } from "react";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { getToken, isAuthenticated } from "@/lib/auth";

import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Keys from "@/pages/keys";
import Sellers from "@/pages/sellers";
import Prices from "@/pages/prices";
import Settings from "@/pages/settings";

const queryClient = new QueryClient();

setAuthTokenGetter(() => getToken());

function ProtectedRoute({ component: Component }: { component: any }) {
  const [location, setLocation] = useLocation();

  useEffect(() => {
    if (!isAuthenticated()) {
      setLocation("/login");
    }
  }, [location, setLocation]);

  if (!isAuthenticated()) return null;

  return <Component />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Switch>
            <Route path="/login" component={Login} />
            <Route path="/" component={() => <ProtectedRoute component={Dashboard} />} />
            <Route path="/dashboard" component={() => <ProtectedRoute component={Dashboard} />} />
            <Route path="/keys" component={() => <ProtectedRoute component={Keys} />} />
            <Route path="/sellers" component={() => <ProtectedRoute component={Sellers} />} />
            <Route path="/prices" component={() => <ProtectedRoute component={Prices} />} />
            <Route path="/settings" component={() => <ProtectedRoute component={Settings} />} />
            <Route component={NotFound} />
          </Switch>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
