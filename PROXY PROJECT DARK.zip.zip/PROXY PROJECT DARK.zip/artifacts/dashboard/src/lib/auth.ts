export function getToken(): string | null {
  return localStorage.getItem("auth_token");
}

export function setToken(token: string | null): void {
  if (token) {
    localStorage.setItem("auth_token", token);
  } else {
    localStorage.removeItem("auth_token");
  }
}

export function isAuthenticated(): boolean {
  return !!getToken();
}
