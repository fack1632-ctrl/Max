import { ReactNode, useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { setToken, getToken } from "@/lib/auth";
import { Terminal, LayoutDashboard, Key, Users, DollarSign, LogOut, Settings2, Power, Radio } from "lucide-react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export function Layout({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const [botEnabled, setBotEnabled] = useState<boolean | null>(null);
  const [botRunning, setBotRunning] = useState<boolean>(false);
  const [toggling, setToggling] = useState(false);
  const [starting, setStarting] = useState(false);

  useEffect(() => {
    fetch(`${BASE}/api/bot/status`, {
      headers: { Authorization: `Bearer ${getToken()}` },
    })
      .then((r) => r.json())
      .then((d) => {
        setBotEnabled(d.enabled ?? true);
        setBotRunning(d.running ?? false);
      })
      .catch(() => setBotEnabled(true));
  }, []);

  const toggleBot = async () => {
    if (toggling) return;
    setToggling(true);
    try {
      const res = await fetch(`${BASE}/api/bot/toggle`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const d = await res.json();
      setBotEnabled(d.enabled);
    } finally {
      setToggling(false);
    }
  };

  const startBot = async () => {
    if (starting) return;
    setStarting(true);
    try {
      const endpoint = botRunning ? "/api/bot/stop" : "/api/bot/start";
      const res = await fetch(`${BASE}${endpoint}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const d = await res.json();
      setBotRunning(d.running ?? !botRunning);
    } finally {
      setStarting(false);
    }
  };

  const handleLogout = () => {
    setToken(null);
    setLocation("/login");
  };

  const navItems = [
    { href: "/dashboard", label: "Overview",   icon: LayoutDashboard },
    { href: "/keys",      label: "Keys",        icon: Key             },
    { href: "/sellers",   label: "Sellers",     icon: Users           },
    { href: "/prices",    label: "Prices",      icon: DollarSign      },
    { href: "/settings",  label: "Settings",    icon: Settings2       },
  ];

  return (
    <div className="flex h-screen bg-background text-foreground font-mono overflow-hidden">
      {/* Sidebar */}
      <aside className="w-60 shrink-0 flex flex-col bg-card border-r border-border/60 p-3 gap-2">
        {/* Logo */}
        <div className="flex items-center gap-2.5 px-3 py-3 mb-1">
          <div className="w-8 h-8 rounded-xl bg-primary/15 flex items-center justify-center border border-primary/20">
            <Terminal size={16} className="text-primary" />
          </div>
          <span className="font-bold text-sm uppercase tracking-widest text-primary">FF_PROXY</span>
        </div>

        {/* Nav */}
        <nav className="flex-1 flex flex-col gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href || location.startsWith(item.href + "/");
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold uppercase tracking-wide transition-all duration-150 ${
                  isActive
                    ? "bg-primary/12 text-primary border border-primary/20"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/60 border border-transparent"
                }`}
              >
                <Icon size={16} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Bot Start/Stop */}
        <button
          onClick={startBot}
          disabled={starting}
          className={`flex items-center gap-3 px-3 py-2.5 w-full rounded-xl border text-sm font-bold uppercase tracking-wide transition-all duration-200 ${
            botRunning
              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20"
              : "bg-muted/40 text-muted-foreground border-border/60 hover:bg-muted/70 hover:text-foreground"
          } disabled:opacity-50`}
          title={botRunning ? "Stop bot" : "Start bot"}
        >
          <Radio size={16} className={botRunning ? "animate-pulse" : ""} />
          <span className="flex-1 text-left">
            {starting ? "Please wait..." : botRunning ? "Bot: Running" : "Bot: Stopped"}
          </span>
          <span className={`w-2 h-2 rounded-full ${botRunning ? "bg-emerald-400 animate-pulse" : "bg-muted-foreground/40"}`} />
        </button>

        {/* Bot Enable/Disable toggle */}
        <button
          onClick={toggleBot}
          disabled={toggling || botEnabled === null}
          className={`flex items-center gap-3 px-3 py-2.5 w-full rounded-xl border text-sm font-bold uppercase tracking-wide transition-all duration-200 ${
            botEnabled
              ? "bg-primary/8 text-primary border-primary/20 hover:bg-primary/15"
              : "bg-red-500/8 text-red-400 border-red-500/20 hover:bg-red-500/15"
          } disabled:opacity-50`}
        >
          <Power size={16} />
          <span className="flex-1 text-left">
            {botEnabled === null ? "Loading..." : botEnabled ? "Accept: ON" : "Accept: OFF"}
          </span>
          <span className={`w-2 h-2 rounded-full ${botEnabled ? "bg-primary" : "bg-red-400"}`} />
        </button>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-2.5 w-full rounded-xl text-muted-foreground hover:text-destructive hover:bg-destructive/8 border border-transparent hover:border-destructive/20 transition-all duration-150 text-sm font-semibold uppercase tracking-wide"
        >
          <LogOut size={16} />
          Sign Out
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto bg-background">
        {children}
      </main>
    </div>
  );
}
